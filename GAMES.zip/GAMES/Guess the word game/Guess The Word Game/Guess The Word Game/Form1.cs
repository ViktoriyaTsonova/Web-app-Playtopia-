﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Guess_The_Word_Game
{
    public partial class Form1 : Form
    {
        List<string> words = new List<string>();
        string newText;
        int i = 0;
        int guessed = 0;



        public Form1()
        {
            InitializeComponent();
            Setup();
        }

        private void lblWord_Click(object sender, EventArgs e)
        {

        }

        private void KeyIsPressed(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar==(char)Keys.Enter)
            {
                if (words[i].ToLower() == textBox1.Text.ToLower())
                {
                    if (i<words.Count - 1)
                    { 
                        MessageBox.Show(" Вярно! ");
                        textBox1.Text = "";
                        i += 1;
                        newText = Scramble(words[i]);
                        lblWord.Text = newText;
                        lblInfo.Text = "Думи: " + (i + 1) + "  от  " + words.Count;
                        guessed = 0;
                        lblGuessed.Text = "Опити: " + guessed + " пъти";
                    }

                    else
                    {
                        lblWord.Text = "Ти спечели, Поздравления!";
                        return;
                            
                    }
                }
                else
                {
                    guessed += 1;
                    lblGuessed.Text = "Опити: " + guessed + " пъти";
                }
                e.Handled = true;
            }
        }
            private void Setup()
        {
            words = File.ReadLines("Думи.txt").ToList();
            newText = Scramble(words[i]);
            lblWord.Text = newText;
            lblInfo.Text = "Думи: " + (i + 1) + "  от  " + words.Count;
        }

        private string Scramble(string text)
        {
           
            return new string(text.ToCharArray().OrderBy(x => Guid.NewGuid()).ToArray());
        }


    }
}
